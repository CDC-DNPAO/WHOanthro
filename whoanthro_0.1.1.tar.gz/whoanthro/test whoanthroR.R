# compare wanthro (mine) and anthro (CRAN/WHO)

dref <- fread('~/Sync/R/Anal/Growth_Charts/Data/WHOref_d.csv')[
   denom=='forlen',.(sex,agedays,len,wfl_l,wfl_m,wfl_s)]
dref[len==65]

# note that WFL does NOT include the weight for height that's in CRAN anthro!
d <- read_sas('/Users/davidfreedman/Downloads/WHOref_d.sas7bdat') |> setDT(); d; qsu(d)

d <- pread(p0(.ss,'NCHS_data_management/NH4/Data/nhanes-data-dec-2020.parq')); sn(d)
d <- d[agem<60]
v=.c(id, sex,ageexmo,weight,height,length,bmi,headc,studyc); fnames(v,d); 
d <- d[,..v];
setnames(d,.c(id, sex,agem,wt,ht,len,bmi,headc,studyc)); qsu(d)
d[,let(lenhei=fcase(
   agem<24,len,
   agem>=24,ht), 
   agedays=floor((agem+0.5)*30.4375)
)]
d[agem<24 & lenhei!=len]; d[agem<24,.(agem,agedays,lenhei,len,ht)][order(agem)]
d[agem>=24 & lenhei!=ht]; d[agem>=24,.(agem,agedays,lenhei,len,ht)][order(agem)]
d[,let(bmi=wt/(lenhei/100)^2)]
qsu(d)
data <- d
data[id==65170]
setwd('~/sync/R/Anal/Growth_Charts/WHO gcs/data'); list.files()

# for testing in sas
d <- setnames(data, .c(id,sex,agem,weight,st_height,len,bmi,headcir,studyc,height,agedays))
d
fwrite(d, 'who_test.csv')

d <- fread('~/Downloads/nhanes.csv'); qsu(d)
x <- grepv('^_|sf|arm',names(d)); x; d[,(x):=NULL]
d
d1 <- whoanthro(d, agedays, weight, height, headcir, bmi); qsu(d1)
with(d1[agedays<731], all.equal(lhaz,haz))
with(d1[agedays<731], all.equal(i.waz,waz))
with(d1[agedays<731], all.equal(i.bmiz,bmiz))
with(d1[agedays<731], all.equal(whz,wflz))
with(d1[agedays<731], all.equal(i.headcz,headcz))

d1 <- whoanthro(data, agedays, wt, lenhei, i,headc=NA); qsu(d1)
d1
library(anthro)
args(anthro_zscores)
d2 <- with(data,anthro_zscores(sex=sex,age=agedays,is_age_in_month=FALSE,
                     weight=wt,lenhei=lenhei,headc=headc))
qsu(d1)
qsu(d2)
d2 <- cbind(data,d2); qsu(d2)

d <- d1[d2, on='id']
options(digits=6)
qsu(d[,.(waz,zwei,laz,zlen,headcz,zhc,bmiz,zbmi,wflz,zwfl)])
corp(d[,.(waz,laz,headcz,bmiz,wflz,zwei,zlen,zhc,zbmi,zwfl)])[1:5,6:10]

d[is.na(bmiz) & !is.na(zbmi), .(sex,agedays,len,ht,lenhei,bmiz,zbmi)][order(agedays)]
d[is.na(wflz) & !is.na(zwfl), .(sex,agedays,len,ht,lenhei,wflz,zwfl)][order(len)]
d[is.na(wflz) & !is.na(zwfl) & lenhei>110, 
  .(id,sex,agedays,agey=floor(agedays/365.25),len,ht,lenhei,wflz,zwfl)
  ][order(lenhei)]
dref <- fread('~/Sync/R/Anal/Growth_Charts/Data/WHOref_d.csv'); dref
qsu(dref$len)

# bmiz and wfk