.datatable.aware <- TRUE
    
# data.table evaluates column names non-standardly inside DT[...], so R CMD
# check sees them as undefined global variables. Declaring them here silences
# the "no visible binding for global variable" NOTEs.
#
# Includes: "." (the .() alias for list), "..keep" (the ..prefix for a variable
# holding column names), and "i.wflz" (the i. prefix used in update joins).
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c(
    # data.table syntax
    ".", "..keep", "i.wflz",
    # internal / input columns
    "seq_", "sex", "sexn", "denom", "len",
    "agedays", "wt", "lenhei", "headc", "bmi",
    "len_hei", "head_circ",
    # LMS columns from the reference table
    "wei_l", "wei_m", "wei_s",
    "len_l", "len_m", "len_s",
    "bmi_l", "bmi_m", "bmi_s",
    "headc_l", "headc_m", "headc_s",
    "wfl_l", "wfl_m", "wfl_s",
    # computed z-scores and BIV flags
    "waz", "lhaz", "wflz", "bmiz", "headcz",
    "fwaz", "flhaz", "fwflz", "fbmiz", "fheadcz",
    # package reference dataset
    "who_ref_data"
  ))
}